package com.ali.karpuzgetiryiyelim

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class GameViewModel : ViewModel() {
    private val _gameState = MutableStateFlow(GameState())
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    private var gameAreaWidth = 1920f
    private var gameAreaHeight = 1080f
    private val gravity = 0.2f // Even lower gravity for slower balls

    private val colors = listOf(Color.Red, Color.Green, Color.Magenta, Color.Yellow, Color.Blue, Color.Cyan)

    init {
        startGameLoop()
    }

    fun setGameArea(width: Float, height: Float) {
        gameAreaWidth = width
        gameAreaHeight = height
    }

    fun navigateTo(screen: GameScreen) {
        if (screen == GameScreen.GAME) {
            _gameState.update { it.copy(score = 0, misses = 0, fruits = emptyList(), currentScreen = screen) }
        } else {
            _gameState.update { it.copy(currentScreen = screen) }
        }
    }

    private fun startGameLoop() {
        viewModelScope.launch {
            while (true) {
                if (_gameState.value.currentScreen == GameScreen.GAME) {
                    updatePhysics()
                    checkSpawning()
                }
                delay(16)
            }
        }
    }

    private fun checkSpawning() {
        val state = _gameState.value
        val maxBalls = when(state.difficulty) {
            Difficulty.EASY -> 2
            Difficulty.MEDIUM -> 3
            Difficulty.HARD -> 4
        }
        
        if (state.fruits.size < maxBalls) {
            spawnFruit()
        }
    }

    private fun spawnFruit() {
        val difficulty = _gameState.value.difficulty
        
        val id = System.currentTimeMillis() + Random.nextLong(0, 1000)
        val x = (Random.nextFloat() * 0.6f + 0.2f) * gameAreaWidth
        val y = gameAreaHeight + 50f
        
        // Slower and uniform speed across all difficulties
        val speedMultiplier = 0.8f 
        
        val vx = (Random.nextFloat() - 0.5f) * 6f * speedMultiplier
        
        // Base launch velocity
        var launchVelocity = -12f - Random.nextFloat() * 3f
        
        // Slightly higher height for Easy mode
        if (difficulty == Difficulty.EASY) {
            launchVelocity -= 2f
        }
        
        val vy = launchVelocity * speedMultiplier
        val color = colors.random()
        
        _gameState.update { it.copy(fruits = it.fruits + Fruit(id, x, y, vx, vy, color)) }
    }

    private fun updatePhysics() {
        _gameState.update { state ->
            var newMisses = 0
            val updatedFruits = state.fruits.map { fruit ->
                val newX = fruit.x + (if (fruit.isCut) fruit.vx + fruit.sliceVelocityX else fruit.vx)
                val newY = fruit.y + (if (fruit.isCut) fruit.vy + fruit.sliceVelocityY else fruit.vy)
                val newVy = fruit.vy + gravity
                
                var missed = fruit.isMissed
                if (!fruit.isCut && !fruit.isMissed && newY >= gameAreaHeight + 50f) {
                    newMisses++
                    missed = true
                }
                
                fruit.copy(
                    x = newX,
                    y = newY,
                    vy = newVy,
                    isMissed = missed
                )
            }
            
            val finalMisses = state.misses + newMisses
            val filteredFruits = updatedFruits.filter { it.y < gameAreaHeight + 100f }

            val maxMisses = when(state.difficulty) {
                Difficulty.EASY -> 7
                Difficulty.MEDIUM -> 4
                Difficulty.HARD -> 2
            }

            if (finalMisses >= maxMisses) {
                state.copy(fruits = emptyList(), misses = finalMisses, currentScreen = GameScreen.GAME_OVER)
            } else {
                state.copy(fruits = filteredFruits, misses = finalMisses)
            }
        }
    }

    fun onSwipe(start: Offset, end: Offset) {
        val state = _gameState.value
        val swipeAngle = atan2(end.y - start.y, end.x - start.x)
        
        state.fruits.forEach { fruit ->
            if (!fruit.isCut) {
                val distance = distanceToSegment(Offset(fruit.x, fruit.y), start, end)
                if (distance < fruit.radius) {
                    cutFruit(fruit, distance, swipeAngle)
                }
            }
        }
    }

    private fun cutFruit(fruit: Fruit, distance: Float, angle: Float) {
        _gameState.update { state ->
            val points = ScoringSystem.calculatePoints()
            
            // Perpendicular dispersion
            val dispAngle = angle + (Math.PI.toFloat() / 2f)
            val dispPower = 5f
            val dx = cos(dispAngle) * dispPower
            val dy = sin(dispAngle) * dispPower

            val updatedFruits = state.fruits.map {
                if (it.id == fruit.id) {
                    it.copy(
                        isCut = true, 
                        sliceAngle = Math.toDegrees(angle.toDouble()).toFloat(),
                        sliceVelocityX = dx,
                        sliceVelocityY = dy
                    )
                } else it
            }
            state.copy(
                score = state.score + points,
                fruits = updatedFruits
            )
        }
    }

    private fun distanceToSegment(p: Offset, a: Offset, b: Offset): Float {
        val ab = b - a
        val ap = p - a
        val lengthSquared = ab.x * ab.x + ab.y * ab.y
        if (lengthSquared == 0f) return sqrt(ap.x * ap.x + ap.y * ap.y)
        val t = ((ap.x * ab.x + ap.y * ab.y) / lengthSquared).coerceIn(0f, 1f)
        val projection = a + ab * t
        val distVec = p - projection
        return sqrt(distVec.x * distVec.x + distVec.y * distVec.y)
    }

    fun setDifficulty(difficulty: Difficulty) {
        _gameState.update { it.copy(difficulty = difficulty) }
    }

    fun addCoin(type: CoinType, amount: Int = 1) {
        _gameState.update { currentState ->
            val updatedCoins = currentState.coins.toMutableMap()
            updatedCoins[type] = (updatedCoins[type] ?: 0) + amount
            currentState.copy(coins = updatedCoins)
        }
    }

    fun addDifficultyCoin(difficulty: Difficulty, amount: Int = 1) {
        _gameState.update { currentState ->
            val updatedDiffCoins = currentState.difficultyCoins.toMutableMap()
            updatedDiffCoins[difficulty] = (updatedDiffCoins[difficulty] ?: 0) + amount
            currentState.copy(difficultyCoins = updatedDiffCoins)
        }
    }
}

