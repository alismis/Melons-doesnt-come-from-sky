package com.ali.karpuzgetiryiyelim

import androidx.compose.ui.graphics.Color

enum class Difficulty {
    EASY, MEDIUM, HARD
}

enum class CoinType {
    BRONZE, SILVER, GOLD
}

data class Fruit(
    val id: Long,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val color: Color,
    var isCut: Boolean = false,
    var isMissed: Boolean = false,
    var sliceAngle: Float = 0f,
    var sliceVelocityX: Float = 0f,
    var sliceVelocityY: Float = 0f,
    val radius: Float = 50f
)

object ScoringSystem {
    fun calculatePoints(): Int {
        return 1
    }
}

enum class GameScreen {
    MENU, DIFFICULTY_SELECT, GAME, GAME_OVER
}

data class GameState(
    val score: Int = 0,
    val misses: Int = 0,
    val currentScreen: GameScreen = GameScreen.MENU,
    val difficulty: Difficulty = Difficulty.EASY,
    val coins: Map<CoinType, Int> = mapOf(
        CoinType.BRONZE to 0,
        CoinType.SILVER to 0,
        CoinType.GOLD to 0
    ),
    val difficultyCoins: Map<Difficulty, Int> = mapOf(
        Difficulty.EASY to 0,
        Difficulty.MEDIUM to 0,
        Difficulty.HARD to 0
    ),
    val fruits: List<Fruit> = emptyList()
)

