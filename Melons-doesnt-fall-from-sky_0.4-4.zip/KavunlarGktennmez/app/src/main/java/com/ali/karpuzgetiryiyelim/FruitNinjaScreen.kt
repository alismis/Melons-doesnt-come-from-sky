package com.ali.karpuzgetiryiyelim

import android.app.Activity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.max

@Composable
fun FruitNinjaScreen(
    gameViewModel: GameViewModel = viewModel()
) {
    val gameState by gameViewModel.gameState.collectAsState()

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        when (gameState.currentScreen) {
            GameScreen.MENU -> MainMenu(gameViewModel)
            GameScreen.DIFFICULTY_SELECT -> DifficultySelect(gameViewModel)
            GameScreen.GAME -> GameCanvas(gameViewModel, gameState)
            GameScreen.GAME_OVER -> GameOverScreen(gameViewModel, gameState)
        }
    }
}

@Composable
fun MainMenu(viewModel: GameViewModel) {
    var shopMsg by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val context = LocalContext.current

    if (showSettings) {
        Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            Button(onClick = { (context as? Activity)?.finish() }) {
                Text("Get Out")
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { showSettings = false }) {
                Text("Back")
            }
        }
    } else {
        Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Kavunlar Gokten Inmez", color = Color.White, style = MaterialTheme.typography.displayMedium)
            Spacer(Modifier.height(32.dp))
            
            Button(onClick = { shopMsg = "well you gotta wait for that button to work" }, Modifier.width(200.dp)) {
                Text("Shop")
            }
            if (shopMsg.isNotEmpty()) {
                Text(shopMsg, color = Color.Red, modifier = Modifier.padding(8.dp))
            }
            
            Spacer(Modifier.height(16.dp))
            Button(onClick = { viewModel.navigateTo(GameScreen.DIFFICULTY_SELECT) }, Modifier.width(200.dp)) {
                Text("Play")
            }
            
            Spacer(Modifier.height(16.dp))
            Button(onClick = { showSettings = true }, Modifier.width(200.dp)) {
                Text("Settings")
            }
        }
    }
}

@Composable
fun DifficultySelect(viewModel: GameViewModel) {
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Choose Difficulty", color = Color.White, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(32.dp))
        
        Button(onClick = { 
            viewModel.setDifficulty(Difficulty.EASY)
            viewModel.navigateTo(GameScreen.GAME)
        }, Modifier.width(200.dp)) { Text("Easy") }
        
        Spacer(Modifier.height(16.dp))
        Button(onClick = { 
            viewModel.setDifficulty(Difficulty.MEDIUM)
            viewModel.navigateTo(GameScreen.GAME)
        }, Modifier.width(200.dp)) { Text("Medium") }
        
        Spacer(Modifier.height(16.dp))
        Button(onClick = { 
            viewModel.setDifficulty(Difficulty.HARD)
            viewModel.navigateTo(GameScreen.GAME)
        }, Modifier.width(200.dp)) { Text("Hard") }
        
        Spacer(Modifier.height(32.dp))
        Button(onClick = { viewModel.navigateTo(GameScreen.MENU) }) { Text("Back") }
    }
}

@Composable
fun GameCanvas(gameViewModel: GameViewModel, gameState: GameState) {
    val swipePoints = remember { mutableStateListOf<Offset>() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onGloballyPositioned {
                gameViewModel.setGameArea(it.size.width.toFloat(), it.size.height.toFloat())
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { 
                        swipePoints.clear()
                        swipePoints.add(it)
                    },
                    onDragEnd = { swipePoints.clear() },
                    onDragCancel = { swipePoints.clear() },
                    onDrag = { change, dragAmount ->
                        val start = change.position - dragAmount
                        val end = change.position
                        gameViewModel.onSwipe(start, end)
                        swipePoints.add(end)
                        if (swipePoints.size > 10) swipePoints.removeAt(0)
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            gameState.fruits.forEach { fruit ->
                if (!fruit.isCut) {
                    drawCircle(color = fruit.color, radius = fruit.radius, center = Offset(fruit.x, fruit.y))
                } else {
                    val age = max(0L, System.currentTimeMillis() - fruit.id) / 16f
                    val offsetX = fruit.sliceVelocityX * age * 0.5f
                    val offsetY = fruit.sliceVelocityY * age * 0.5f

                    withTransform({
                        translate(fruit.x - offsetX, fruit.y - offsetY)
                        rotate(fruit.sliceAngle, pivot = Offset.Zero)
                    }) {
                        drawArc(
                            color = fruit.color, startAngle = 180f, sweepAngle = 180f, useCenter = true,
                            topLeft = Offset(-fruit.radius, -fruit.radius),
                            size = androidx.compose.ui.geometry.Size(fruit.radius * 2, fruit.radius * 2)
                        )
                    }
                    withTransform({
                        translate(fruit.x + offsetX, fruit.y + offsetY)
                        rotate(fruit.sliceAngle, pivot = Offset.Zero)
                    }) {
                        drawArc(
                            color = fruit.color, startAngle = 0f, sweepAngle = 180f, useCenter = true,
                            topLeft = Offset(-fruit.radius, -fruit.radius),
                            size = androidx.compose.ui.geometry.Size(fruit.radius * 2, fruit.radius * 2)
                        )
                    }
                }
            }

            if (swipePoints.size > 1) {
                for (i in 0 until swipePoints.size - 1) {
                    drawLine(color = Color.White, start = swipePoints[i], end = swipePoints[i + 1], strokeWidth = 10f, cap = StrokeCap.Round)
                }
            }
        }

        Column(Modifier.padding(16.dp).align(Alignment.TopStart)) {
            Text("Score: ${gameState.score}", color = Color.White, style = MaterialTheme.typography.titleLarge)
            val maxMisses = when(gameState.difficulty) {
                Difficulty.EASY -> 7
                Difficulty.MEDIUM -> 4
                Difficulty.HARD -> 2
            }
            Text("Chances Left: ${maxMisses - gameState.misses}", color = Color.White)
        }
    }
}

@Composable
fun GameOverScreen(viewModel: GameViewModel, state: GameState) {
    Column(Modifier.fillMaxSize().background(Color(0xFF8B0000)), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("GAME OVER", color = Color.White, style = MaterialTheme.typography.displayMedium)
        Spacer(Modifier.height(16.dp))
        Text("You used all your chances, your point was ${state.score} congrats", 
            color = Color.White, style = MaterialTheme.typography.titleLarge, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(16.dp))
        Spacer(Modifier.height(32.dp))
        Button(onClick = { viewModel.navigateTo(GameScreen.MENU) }) {
            Text("Back to Menu")
        }
    }
}
